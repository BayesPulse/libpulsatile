//struct AssociationChain { NumericMatrix association; };


//    arma::mat association_chain;

//NumericMatrix addattribs_association_chain(NumericMatrix out);




//// Function for adding attributes to association_chain
//NumericMatrix Chains::addattribs_association_chain(NumericMatrix out) {
//
//  // TODO: clarify names -- check Karen's code and AssocEstimates in population.h
//  colnames(out) = CharacterVector::create("iteration", 
//                                          "cluster_size",
//                                          "cluster_width");
//  out.attr("class") = "association_chain";
//
//  return out;
//
//}


