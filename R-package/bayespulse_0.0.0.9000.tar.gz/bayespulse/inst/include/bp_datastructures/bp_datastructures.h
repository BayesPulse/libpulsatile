#ifndef GUARD_bp_datastructures_h
#define GUARD_bp_datastructures_h

#include <bp_datastructures/chains.h>
#include <bp_datastructures/patient.h>
#include <bp_datastructures/patientdata.h>
#include <bp_datastructures/patientestimates.h>
#include <bp_datastructures/patientpriors.h>
#include <bp_datastructures/population.h>
#include <bp_datastructures/pulseestimates.h>
#include <bp_datastructures/utils.h>

#endif

