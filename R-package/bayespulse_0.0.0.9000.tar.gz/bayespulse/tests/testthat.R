library(testthat)
library(bayespulse)

test_check("bayespulse")
