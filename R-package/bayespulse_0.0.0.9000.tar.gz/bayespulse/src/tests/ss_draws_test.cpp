#include <RcppArmadillo.h>
#include <RInside.h>
#include <bp_mcmc/counter.h>
#include <bp_mcmc/proposalvariance.h>
#include <bp_mcmc/mh.h>
#include <testing/catch.h>


//
// Test the Counter class
//

TEST_CASE( "Draw Location", "[draw_]" ) {
  SECTION( "can iterate/add reject" ) {

  }
}
