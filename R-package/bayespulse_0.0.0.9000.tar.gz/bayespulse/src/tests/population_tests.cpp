//#include <RcppArmadillo.h>
//#include <RInside.h>
////#include "patient.h"
////#include "datastructures.h"
////#include "population.h"
//#include "catch.h"


//
// population_tests.cpp
//     Population class tests
//




